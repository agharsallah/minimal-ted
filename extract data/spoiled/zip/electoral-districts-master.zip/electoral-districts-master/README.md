# electoral-districts

Distinct territorial subdivision for holding the following elections in Tunisia:
* [NCA elections 2011]
* [Parliamentary elections 2014]
* [Presidential elections 2014]

The data file contains 3 features :
* CIRC_ID : used for joins with results data
* NAME_EN : district name in English
* NAME_AR : district name in arabic


License
----

pddl



[NCA elections 2011]:http://en.wikipedia.org/wiki/Tunisian_Constituent_Assembly_election,_2011
[Parliamentary elections 2014]:http://en.wikipedia.org/wiki/Tunisian_parliamentary_election,_2014
[Presidential elections 2014]:http://en.wikipedia.org/wiki/Tunisian_presidential_election,_2014
